<template>
  <div class="terms">
    <h1>Terms &amp; Conditions</h1>

    <h2>WELCOME TO SIMUL</h2>

    <p>
      Welcome to SIMUL, a website and online service owned and operated by Quod
      Architecture. (“SIMUL”, “we”, “us” or “our”). These Terms of Service (the
      “Terms”) govern your access to and use of SIMUL (“we” or “our”) websites
      and services, including the App (as defined below) (collectively, the
      “Services”), so please carefully read them before using the Services.
    </p>

    <p>
      By using the Services, you agree to be bound by these Terms. If you are
      using the Services on behalf of an organization, you are agreeing to these
      Terms for that organization and promising that you have the authority to
      bind that organization to these terms. In that case, “you” and “your” will
      refer to that organization.
    </p>

    <p>
      When you use the Services, you represent that: (a) the information you
      submit is truthful and accurate; (b) you will update your contact
      information if it changes so that we can contact you; (c) your use of the
      Services do not violate any applicable law or regulation; and (d) you will
      comply with the rules for on-line conduct and making Contributions (as
      defined in Section 2 below) to the Services, as discussed in Section 2
      below. You further represent and warrant that you will comply with all
      local rules regarding on-line conduct and acceptable Contributions.
    </p>

    <p>
      Regardless of how you decide to use this Site, your conduct on this Site
      is governed by this Agreement, the terms of the SIMUL Privacy Policy
      (www.SIMUL.co/terms/privacy-policy) and the SIMUL DMCA Notice
      (www.SIMUL.co/copyright-infringement-notification).
    </p>

    <h3>1. USE OF THE SERVICES</h3>

    <p>Who Uses SIMUL?</p>

    <p>
      There are personal and professional uses for SIMUL. Users may want to use
      SIMUL to organize content from various sources and to collaborate with
      other users. Businesses may be interested in using SIMUL to collaborate on
      projects. Schools may explore using SIMUL for educational purposes. These
      are only some of the possible uses.
    </p>

    <p>
      There are different account types. The details and pricing for all account
      types is available at www.SIMUL.co/pricing.
    </p>

    <p>What is SIMUL?</p>

    <p>
      SIMUL is a robust platform for visual collaboration and group problem
      solving. In particular, SIMUL users are able to integrate content from
      multiple sources, arrange it freely in a two-dimensional canvas, and share
      this content with other people.
    </p>

    <p>The SIMUL Platforms</p>

    <p>
      SIMUL is a service that can be consumed by any of its multiple apps. There
      are Desktop, Web and Mobile apps. Versions of the desktop app are
      available for Apple OSX and Microsoft Windows, and mobile versions are
      available for iPhone®, iPad® and Android™ devices. iPhone and iPad are
      trademarks of Apple Inc., registered in the U.S. and other countries. App
      Store is a service mark of Apple Inc. Android™ platform is a trademark of
      Google Inc.
    </p>

    <p>SIMULs</p>

    <p>
      SIMULs (“SIMULs”) are digital visual containers. They are scrollable and
      zoomable two-dimensional canvases. SIMULs can hold pictures, links to web
      content, links to files/documents, and text which can be arranged freely
      on the canvas. Each of the elements in a SIMUL has a link that could be
      shareable. The SIMUL itself is shareable as well. The SIMUL creator can
      invite other people (by email, SIMUL username or by creating a special
      link) to either collaborate or view a SIMUL.
    </p>

    <p>Rooms</p>

    <p>
      SIMUL can be organized in Rooms. Typically, a team will create a room for
      a specific project and host all the SIMULs related to that project inside
      the room. Users can be invited into a room and room owners can define
      individual user permissions to create SIMULs inside that room (not
      necessarily everyone invited to the room is allowed to create SIMULs
      inside it). All members of a room have access to the SIMULs hosted in the
      room, but SIMULs might have extra members that are not part of the room
      (i.e. you invite a client to view a specific SIMUL in the room without
      giving him access to the whole room). An Account administrator is able to
      define which users have permission to create rooms.
    </p>

    <h4>Can Children Use SIMUL?</h4>

    <p>
      The Services are not directed toward children. If Children use the
      Services, we expect that such use will be with the guidance, supervision
      and consent of parents, guardians or authorized school officials, who, in
      turn, are responsible for ensuring that children understand their rights
      and obligations under these Terms and the SIMUL Privacy Policy. In the
      United States, if you are a school that includes children under the age of
      13 and you would like to use the Services with such children, you are
      responsible for complying with the Children’s Online Privacy Protection
      Act (“COPPA”) and if applicable, the Family Educational Rights and Privacy
      Act (“FERPA”). Accordingly, in order to use the Services, you must notify
      parents/guardians of the information to be collected from children under
      the age of 13 and obtain consent from the parent/guardian prior to
      collecting and sharing such information. COPPA permits schools to acts as
      agents for parents/guardians in providing such consent. Please see
      https://www.ftc.gov/privacy/coppafaqs.shtm#schools.
    </p>

    <p>
      If you are a school outside of the United States, please make sure that
      you are complying with any laws that apply to the collection and/or
      sharing of personal information of children before submitting information
      to the Services or otherwise using the Services.
    </p>

    <h3>2. RULES GOVERNING CONTRIBUTIONS.</h3>

    <p>
      Please read our Privacy Policy, available at
      www.SIMUL.co/terms/privacy-policy, to understand your privacy protections.
    </p>

    <p>What are Contributions?</p>

    <p>
      The Services are designed to facilitate collaboration. It is possible for
      a user to post or submit a wide range of content to the Services
      (collectively, “Contributions”) and to collaborate with other users on
      SIMULs containing such Contributions. Contributions may include, but are
      not limited to, photos, videos, text, drawings/sketches, Web content
      (including files or documents from third party online storage services,
      notes from third party note-taking applications, and links from third
      party websites), and other materials. Please be aware that you are
      entirely responsible for the content of, and any harm resulting from, any
      of your Contributions.
    </p>

    <p>Contributions to SIMULs</p>

    <p>
      Contributions to SIMULs will be treated as confidential. Only users with
      permission (granted by you or provided in accordance with our Privacy
      Policy) may access SIMULs.
    </p>

    <p>Users</p>

    <p>
      When you invite users to Edit, they will be able to access all element
      previews, add content to a SIMUL, edit content in the SIMUL, and even
      delete content in the SIMUL. The activity will be logged and presented in
      the Activity Feed. Users can also copy and paste content into another
      SIMUL.
    </p>

    <p>
      When you share your SIMUL by creating View only links, users that access
      that link can only view the content and explore the links/files/documents.
    </p>

    <p>Your Commitment to Our Rules Governing Contributions</p>

    <p>
      When you create or make available a Contribution, you represent and
      warrant that you:
    </p>
    <p>
      Own or have sufficient rights to post your Contributions, on or through
      the Services; Will not post Contributions that violate our or any other
      person’s privacy rights, publicity rights, copyrights or other
      intellectual property rights, or contract rights; Have fully complied with
      any third-party licenses relating to Contributions, agree to pay all
      royalties, fees and any other monies owing any person by reason of
      Contributions that you posted to or through the Services; Will not post
      Contributions that: (i) are defamatory, damaging, disruptive, unlawful,
      inaccurate, pornographic, vulgar, indecent, profane, hateful, racially or
      ethnically offensive, obscene, lewd, lascivious, filthy, threatening,
      excessively violent, harassing, or otherwise objectionable; (ii) incite,
      encourage or threaten immediate physical harm against another, including
      but not limited to, Contributions that promote racism, bigotry, sexism,
      religious intolerance or harm against any group or individual; or (iii)
      contain material that solicits personal information from anyone under 13
      or exploits anyone in a sexual or violent manner; Will not post
      Contributions that contain advertisements or solicit any person to buy or
      sell products or services (other than our products and services); provided
      that, recommending a product or service (including by pinning or including
      a link to it) shall not be deemed a violation of this Section 2(e) so long
      as you disclose in your Contribution any material connection between you
      and the provider of such product or service; Will not use the Services for
      any unauthorized purpose including collecting usernames and/or email
      addresses of other users by electronic or other means for the purpose of
      sending unsolicited email or other electronic communications without our
      express written consent or engage in any framing of, or linking to, the
      Services; Will not post Contributions that constitute, contain, install or
      attempt to install or promote spyware, malware or other computer code,
      whether on our or others’ computers or equipment, designated to enable you
      or others to gather information about or monitor the on-line or other
      activities of another party; Will not transmit chain letters, bulk or junk
      email or interfere with, disrupt, or create an undue burden on the
      Services or the networks or services connected to the Services, including
      without limitation, hacking into the Services, or using the system to send
      unsolicited or commercial emails, bulletins, comments or other
      communications; or Will not impersonate any other person or entity, sell
      or let others use your profile or password, provide false or misleading
      identification or address information, or invade the privacy, or violate
      the personal or proprietary right, of any person or entity.
    </p>

    <h3>3. YOUR RIGHTS IN YOUR CONTRIBUTIONS.</h3>
    <p>
      We do not and will not own your Contributions. That said, for us to make
      your Contributions available on the Services, we will need from you a
      limited license, as described below. We have no rights in your
      Contributions except pursuant to this limited license and any other rights
      you grant us in these Terms.
    </p>

    <h3>4. GRANT OF LICENSE TO US FOR CONTRIBUTIONS.</h3>
    <p>
      As stated in point 3, you retain full ownership to your contributions, but
      we need a license from you so that our handling of your Contributions does
      not violate applicable laws, including copyright. That means that by
      making a Contribution to the Services, you grant us a license to display,
      perform and distribute your Contributions and to modify and reproduce such
      Contributions to enable us to provide the Services. Please note that we
      may need to modify your Contributions to conform to technical requirements
      for viewing on your computer or mobile device.
    </p>

    <p>
      The above license is non-exclusive, royalty-free, irrevocable and
      worldwide. When your Contributions are no longer stored on the Services,
      this license ends. The above license is also sublicensable. This means
      that we may provide some or all of these rights to third parties with whom
      we have contractual relationships, for the limited purpose of providing
      the contracted services that form part of the Services. Please note that
      the above license also applies to Contributions that are submitted through
      or stored on third party services that are integrated with the Services.
      In addition, if in connection with your submission of Contributions stored
      on such integrated third party services we may need to extract those
      Contributions from such services before making such Contributions
      available on the Services, you represent and warrant that accessing and
      extracting such Contributions will not violate the applicable terms of use
      or API license agreement for those services.
    </p>

    <h3>5. USE AND PROTECTION OF ACCOUNT INFORMATION AND PASSWORD.</h3>
    <p>
      You are responsible for maintaining the confidentiality of your account
      information and password, if applicable. You are responsible for all uses
      of your account, whether or not actually or expressly authorized by you.
    </p>

    <h3>6. OUR INTELLECTUAL PROPERTY RIGHTS.</h3>
    <p>
      All of the content on the Services (“Materials”), the trademarks, service
      marks, and logos contained on the Services (“Marks”), are owned by or
      licensed to us and are subject to copyright and other intellectual
      property rights under United States and foreign laws and international
      conventions. The Services and Materials are for your information and
      personal use only and not for commercial exploitation. We reserve all
      rights not expressly granted in and to the Services and Materials. If you
      download or print a copy of the Materials for your own personal use, you
      must retain all trademark, copyright and other proprietary notices
      contained in and on the materials. You agree that you will not circumvent,
      disable or otherwise interfere with security related features of the
      Services or features that prevent or restrict use or copying of any
      Materials or enforce limitations on use of the Services or the Materials.
      You further agree not to access the Services by any means other than
      through the interface that we provide, unless otherwise specifically
      authorized by us in a separate written agreement.
    </p>

    <h3>7. OUR MANAGEMENT OF THE SERVICES/USER MISCONDUCT.</h3>
    <p>
      We may, but are not required to: (a) monitor or review the Services for
      violations of these Terms and for compliance with our policies; (b) report
      to law enforcement authorities and/or take legal action against anyone who
      violates these Terms; (c) refuse, restrict access to or the availability
      of, or remove or disable (to the extent technologically feasible) any
      Contribution or any portion thereof that may violate these Terms, the law
      or any of our policies or are excessive in size or burdensome; and/or (d)
      manage the Services in a manner designed to protect our and third parties’
      rights and property or to facilitate the proper functioning of the
      Services. Our Right to Terminate Users. WITHOUT LIMITING ANY OTHER
      PROVISION OF THESE TERMS, WE RESERVE THE RIGHT TO, IN OUR SOLE DISCRETION
      AND WITHOUT NOTICE OR LIABILITY DENY ACCESS TO AND USE OF THE SERVICES TO
      ANY PERSON FOR ANY REASON OR FOR NO REASON AT ALL, INCLUDING WITHOUT
      LIMITATION FOR BREACH OF ANY REPRESENTATION, WARRANTY OR COVENANT
      CONTAINED IN THESE TERMS, OR OF ANY APPLICABLE LAW OR REGULATION. Risk of
      Harm. Please note that there are risks, including but not limited to the
      risk of physical harm, of dealing with strangers, including persons who
      may be acting under false pretences. Please choose carefully the
      information you post on the Services and that you give to other users of
      the Services. You are discouraged from publicly posting the following
      information on the Services: your full name, telephone numbers and street
      addresses. Despite this prohibition, other people’s information may be
      offensive, harmful or inaccurate, and in some cases will be mislabelled or
      deceptively labelled. You assume all risks associated with dealing with
      other users with whom you come in contact through the Services. We expect
      that you will use caution and common sense when using the Services.
    </p>

    <h3>8. TERM AND SURVIVAL.</h3>
    <p>
      These Terms shall remain in full force and effect while you use the
      Services. You may terminate your use or participation at any time, for any
      reason, by using the “Deactivate Account” option in the App or contacting
      us at: support@SIMUL.co. Upon termination of your Services account for any
      reason, we will close your account, and in most cases, we will give you 30
      days, via notice to your email address on record, to retrieve materials
      contained in the account. Even after your use and participation is
      terminated, these Terms will remain in effect, including sections: 1-3,
      6-9, and 11-17.
    </p>

    <h3>9. COPYRIGHT POLICY.</h3>
    <p>
      We may terminate the account and access rights of any repeat infringer. If
      you are a copyright owner or the legal agent of a copyright owner, and you
      believe that any user submission or content on this Site infringes upon
      your copyrights, you may submit a notification pursuant to our Digital
      Millennium Copyright Act Notice
      (www.SIMUL.co/copyright-infringement-notification)
    </p>

    <h3>10. MODIFICATIONS.</h3>
    <p>
      The Internet and technology are rapidly changing. Accordingly, we may need
      to modify these Terms from time to time. We will post on www.SIMUL.co a
      copy of the modified Terms, which will become effective 30 days after they
      are first posted on www.SIMUL.co. You should regularly review www.SIMUL.co
      to ensure that you are informed of any changes and if you are also a
      registered user, be sure that the email address on record is current. If
      you are a registered user, we will also email you to the email address
      then on record a link to a copy of the modified Terms 30 days before they
      will go in effect. If any modification is unacceptable to you, you shall
      cease using the Services. Your continued access to the Services will
      indicate you have accepted the change.
    </p>

    <h3>11. THIRD PARTY SITES.</h3>
    <p>
      The Services may contain links to other websites (“Third Party Sites”). We
      do not own or operate the Third-Party Sites, and we have not reviewed, and
      cannot review, all of the material, including goods or services, made
      available through Third-Party Sites. The availability of these links on
      the Services does not represent, warrant or imply that we endorse any
      Third-Party Sites or any materials, opinions, goods or services available
      on them. Third party materials accessed through or used by means of the
      Third Party Sites may also be protected by copyright and other
      intellectual property laws.THESE TERMS DO NOT APPLY TO THIRD PARTY SITES.
      BEFORE VISITING A THIRD PARTY SITE BY MEANS OF THE SERVICES OR A LINK
      LOCATED ON THE SERVICES, USERS SHOULD REVIEW THE THIRD PARTY SITE’S TERMS
      AND CONDITIONS, PRIVACY POLICY AND ALL OTHER SITE DOCUMENTS, AND INFORM
      THEMSELVES OF THE REGULATIONS, POLICIES AND PRACTICES OF THESE THIRD PARTY
      SITES.
    </p>

    <h3>12. DISPUTES BETWEEN USERS.</h3>
    <p>
      You are solely responsible for your conduct. You agree that we cannot be
      liable for any dispute that arises between you and any other user.
    </p>

    <h3>13. DISPUTES WITH US, CHOICE OF LAW AND FORUM.</h3>
    <p>
      Except for claims for injunctive or equitable relief or claims regarding
      intellectual property rights (which may be brought in any state court
      located in San Francisco County, California or the United States District
      Court for the Northern District of California, in all cases without the
      posting of a bond), any dispute arising under these Terms shall be finally
      settled in accordance with the Comprehensive Arbitration Rules of the
      Judicial Arbitration and Mediation Service, Inc. (“JAMS”) by three (3)
      arbitrators appointed in accordance with such rules. The arbitration shall
      take place in San Francisco, California, in the English language and the
      arbitral decision may be enforced in any court. The prevailing party in
      any action or proceeding to enforce these Terms shall be entitled to costs
      and attorneys’ fees. You and we further agree that any disputes shall be
      resolved under the substantive law of the State of California (exclusive
      of its choice of law provisions). The Convention for the International
      Sale of Goods shall not apply.
    </p>

    <p>
      You agree not to bring a claim a legal action more than one (1) year after
      the cause of action arose.
    </p>

    <h3>14. DISCLAIMERS.</h3>

    <p>
      ALL CONTRIBUTIONS OR ANY OTHER MATERIALS OR ITEMS PROVIDED THROUGH THE
      SERVICES ARE PROVIDED "AS IS" AND "AS AVAILABLE," WITHOUT WARRANTY OR
      CONDITIONS OF ANY KIND. BY OPERATING THE SERVICES, WE DO NOT REPRESENT OR
      IMPLY THAT WE ENDORSE ANY CONTRIBUTIONS OR ANY OTHER MATERIALS OR ITEMS
      AVAILABLE ON OR LINKED TO BY THE SERVICES, INCLUDING WITHOUT LIMITATION,
      CONTENT HOSTED ON THIRD PARTY SITES, OR THAT WE BELIEVE CONTRIBUTIONS OR
      ANY OTHER MATERIALS OR ITEMS TO BE ACCURATE, USEFUL OR NON-HARMFUL. WE
      CANNOT GUARANTEE AND DO NOT PROMISE ANY SPECIFIC RESULTS FROM USE OF THE
      SERVICES. NO ADVICE OR INFORMATION, WHETHER ORAL OR WRITTEN, OBTAINED BY
      YOU FROM US OR THE SERVICES SHALL CREATE ANY WARRANTY NOT EXPRESSLY STATED
      IN THESE TERMS. YOU AGREE THAT YOUR USE OF THE SERVICES WILL BE AT YOUR
      SOLE RISK. TO THE FULLEST EXTENT PERMITTED BY LAW, WE AND EACH OF OUR
      ADVERTISERS, LICENSORS, SUPPLIERS, OFFICERS, DIRECTORS, INVESTORS,
      EMPLOYEES, AGENTS, SERVICE PROVIDERS AND OTHER CONTRACTORS DISCLAIM ALL
      WARRANTIES, EXPRESS OR IMPLIED IN CONNECTION WITH THE SERVICES AND YOUR
      USE THEREOF. WE MAKE NO WARRANTIES OR REPRESENTATIONS ABOUT THE ACCURACY
      OR COMPLETENESS OF THE SERVICES’ CONTENT, THE CONTENT OF ANY SITE LINKED
      TO THE SERVICES, CONTRIBUTIONS, INFORMATION OR ANY OTHER ITEMS OR
      MATERIALS ON THE SERVICES OR LINKED TO BY THE SERVICES. WE ASSUME NO
      LIABILITY OR RESPONSIBILITY FOR ANY (A) ERRORS, MISTAKES OR INACCURACIES
      OF CONTENT AND MATERIALS, (B) PERSONAL INJURY OR PROPERTY DAMAGE, OF ANY
      NATURE WHATSOEVER, RESULTING FROM YOUR ACCESS TO AND USE OF THE SERVICES,
      (C) ANY UNAUTHORIZED ACCESS TO OR USE OF OUR SECURE SERVERS AND/OR ANY AND
      ALL PERSONAL INFORMATION STORED THEREIN, (D) ANY INTERRUPTION OR CESSATION
      OF TRANSMISSION TO OR FROM THE SERVICES, (E) ANY BUGS, VIRUSES, TROJAN
      HORSES, OR THE LIKE, WHICH MAY BE TRANSMITTED TO OR THROUGH THE SERVICES
      BY ANY THIRD PARTY, AND/OR (F) ANY ERRORS OR OMISSIONS IN ANY CONTENT AND
      MATERIALS OR FOR ANY LOSS OR DAMAGE OF ANY KIND INCURRED AS A RESULT OF
      THE USE OF ANY CONTENT POSTED, TRANSMITTED, OR OTHERWISE MADE AVAILABLE
      VIA THE SERVICES. SOME STATES OR JURISDICTIONS DO NOT ALLOW THE LIMITATION
      OR EXCLUSION OF CERTAIN WARRANTIES, OR THE EXCLUSION OR LIMITATION OF
      CERTAIN DAMAGES. IF YOU RESIDE IN ONE OF THESE STATES OR JURISDICTIONS,
      THE ABOVE LIMITATIONS OR EXCLUSIONS MAY NOT APPLY TO YOU.
    </p>

    <h3>15. LIMITED LIABILITY.</h3>

    <p>
      IN NO EVENT SHALL WE BE LIABLE TO YOU OR ANY THIRD PARTY FOR ANY INDIRECT,
      CONSEQUENTIAL, INCIDENTAL, SPECIAL OR PUNITIVE DAMAGES, INCLUDING LOST
      PROFIT DAMAGES ARISING FROM YOUR USE OF THE SERVICES, CONTRIBUTIONS,
      MATERIALS OR ANY OTHER CONTENT THEREIN. NOTWITHSTANDING ANYTHING TO THE
      CONTRARY CONTAINED IN THESE TERMS, OUR LIABILITY TO YOU IN RESPECT OF ANY
      LOSS OR DAMAGE SUFFERED BY YOU AND ARISING OUT OF OR IN CONNECTION WITH
      THESE TERMS, WHETHER IN CONTRACT, TORT OR FOR BREACH OF STATUTORY DUTY OR
      IN ANY OTHER WAY SHALL NOT EXCEED THE GREATER OF (A) $100 AND (B) THE FEES
      PAID TO US FOR THE SERVICES DURING THE 12-MONTH PERIOD PRECEDING THE
      CLAIM.
    </p>

    <h3>16. INDEMNITY.</h3>

    <p>
      You agree to indemnify and hold us, our subsidiaries, affiliates, and
      licensors and their respective officers, agents, partners and employees,
      harmless from any loss, liability, claim, or demand, including reasonable
      attorneys’ fees, made by any third party due to or arising out of your use
      of the Services, Contributions or Materials in violation of these Terms
      and/or arising from a breach of these Terms and/or any breach of your
      representations and warranties set forth above.
    </p>

    <h3>17. MISCELLANEOUS.</h3>

    <p>Entire Agreement:</p>

    <p>
      These Terms constitutes the entire agreement between you and us regarding
      the use of the Services and supersede any prior or contemporaneous
      understandings and agreements between you and us related to the subject
      matter hereof.
    </p>

    <p>Independent Contractors:</p>

    <p>
      Nothing in these Terms shall be deemed to create an agency, partnership,
      joint venture, employer-employee or franchisor-franchisee relationship of
      any kind between us and any user.
    </p>

    <p>No Third-Party Beneficiaries:</p>

    <p>
      These Terms are between you and us. There are no third-party beneficiaries
      to these Terms.
    </p>

    <p>Section Titles:</p>

    <p>
      The section titles in these Terms are for convenience only and have no
      legal or contractual effect.
    </p>

    <p>Non-Waiver:</p>

    <p>
      Our failure to exercise or enforce any right or provision of these Terms
      shall not operate as a waiver of such right or provision.
    </p>

    <p>Severability:</p>

    <p>
      These Terms operate to the fullest extent permissible by law. If any
      provision or part of a provision of these Terms is unlawful, void, or
      unenforceable, that provision or part of the provision is deemed severable
      from these Terms and shall not affect the validity and enforceability of
      any remaining provisions.
    </p>

    <p>Assignment:</p>

    <p>
      You may not assign your rights under these Terms to any third party; we
      may assign our rights under these Terms without condition.
    </p>
  </div>
</template>

<style scoped>
.terms {
  padding: 50px;
}
</style>
