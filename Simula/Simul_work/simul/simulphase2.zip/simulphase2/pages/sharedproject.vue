<template>
  <div>
    <SharedProject />
  </div>
</template>

<script>
import SharedProject from '~/components/SharedProject'
export default {
  components: {
    SharedProject
  }
};
</script>

<style></style>
