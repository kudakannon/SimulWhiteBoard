<template>
  <div class="about">
    <h1>About</h1>
    <p>
      Simul taken from the larger word 'Simultaneously' has been created to fill
      the gap between professionals and clients when it comes to the aspect of
      sharing ideas, plans, data and documents. This program will allow
      simultaneous input from multiple parties who are working on projects
      collaboratively.
    </p>
  </div>
</template>
