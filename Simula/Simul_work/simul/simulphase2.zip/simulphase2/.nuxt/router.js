import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _68f15cce = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages_about" */))
const _579c6eae = () => interopDefault(import('..\\pages\\createproject.vue' /* webpackChunkName: "pages_createproject" */))
const _2774a764 = () => interopDefault(import('..\\pages\\directorforgotpass.vue' /* webpackChunkName: "pages_directorforgotpass" */))
const _14748569 = () => interopDefault(import('..\\pages\\directorlogin.vue' /* webpackChunkName: "pages_directorlogin" */))
const _22022ed3 = () => interopDefault(import('..\\pages\\directorregister.vue' /* webpackChunkName: "pages_directorregister" */))
const _12329e6a = () => interopDefault(import('..\\pages\\directorresetpassword.vue' /* webpackChunkName: "pages_directorresetpassword" */))
const _595ac4d8 = () => interopDefault(import('..\\pages\\forgotpass.vue' /* webpackChunkName: "pages_forgotpass" */))
const _96326116 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages_login" */))
const _0f6d9e46 = () => interopDefault(import('..\\pages\\privacypolicy.vue' /* webpackChunkName: "pages_privacypolicy" */))
const _119d9cb5 = () => interopDefault(import('..\\pages\\profile.vue' /* webpackChunkName: "pages_profile" */))
const _61fdb3b6 = () => interopDefault(import('..\\pages\\project.vue' /* webpackChunkName: "pages_project" */))
const _14cf3f9e = () => interopDefault(import('..\\pages\\projects.vue' /* webpackChunkName: "pages_projects" */))
const _75f91947 = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages_register" */))
const _34891ed4 = () => interopDefault(import('..\\pages\\resetPassword.vue' /* webpackChunkName: "pages_resetPassword" */))
const _b3ea9cc0 = () => interopDefault(import('..\\pages\\sharedproject.vue' /* webpackChunkName: "pages_sharedproject" */))
const _d5862ada = () => interopDefault(import('..\\pages\\terms.vue' /* webpackChunkName: "pages_terms" */))
const _2981a744 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _68f15cce,
    name: "about"
  }, {
    path: "/createproject",
    component: _579c6eae,
    name: "createproject"
  }, {
    path: "/directorforgotpass",
    component: _2774a764,
    name: "directorforgotpass"
  }, {
    path: "/directorlogin",
    component: _14748569,
    name: "directorlogin"
  }, {
    path: "/directorregister",
    component: _22022ed3,
    name: "directorregister"
  }, {
    path: "/directorresetpassword",
    component: _12329e6a,
    name: "directorresetpassword"
  }, {
    path: "/forgotpass",
    component: _595ac4d8,
    name: "forgotpass"
  }, {
    path: "/login",
    component: _96326116,
    name: "login"
  }, {
    path: "/privacypolicy",
    component: _0f6d9e46,
    name: "privacypolicy"
  }, {
    path: "/profile",
    component: _119d9cb5,
    name: "profile"
  }, {
    path: "/project",
    component: _61fdb3b6,
    name: "project"
  }, {
    path: "/projects",
    component: _14cf3f9e,
    name: "projects"
  }, {
    path: "/register",
    component: _75f91947,
    name: "register"
  }, {
    path: "/resetPassword",
    component: _34891ed4,
    name: "resetPassword"
  }, {
    path: "/sharedproject",
    component: _b3ea9cc0,
    name: "sharedproject"
  }, {
    path: "/terms",
    component: _d5862ada,
    name: "terms"
  }, {
    path: "/",
    component: _2981a744,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
