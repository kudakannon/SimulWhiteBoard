import { ButtonGroupPlugin } from 'bootstrap-vue'
import { ButtonPlugin } from 'bootstrap-vue'
import Vue from 'vue'

Vue.use('b-button', ButtonPlugin)
Vue.use('b-button-group', ButtonGroupPlugin)
