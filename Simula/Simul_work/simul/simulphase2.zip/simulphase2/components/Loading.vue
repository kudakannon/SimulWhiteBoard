<template>
    <div class="text-center text-danger my-2">
            <b-spinner class="align-middle"></b-spinner>
            <strong>Please Wait...</strong>
          </div>
</template>
<script>
export default {
  name: "Loading"
}
</script>