module.exports = {
  client: 'mysql',
  connection: {
    host: '127.0.0.1',
    database: 'simul',
    user: 'root',
    password: 'thisIsASimulPassword1!'
  }
}
